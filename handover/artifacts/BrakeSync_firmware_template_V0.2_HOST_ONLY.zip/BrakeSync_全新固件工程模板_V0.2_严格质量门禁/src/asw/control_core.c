#include "brakesync/control_core.h"

#include <stddef.h>

BrakeSyncControlStatus BrakeSyncControl_Init(BrakeSyncControlResult *result)
{
    if (result == NULL)
    {
        return BRAKESYNC_CONTROL_STATUS_INVALID_ARGUMENT;
    }

    result->input_quality_ready = false;
    result->brake_intent_observed = false;
    result->logical_request_valid = false;
    result->logical_request_permille = 0U;
    result->physical_output_permitted = false;

    return BRAKESYNC_CONTROL_STATUS_OK;
}

BrakeSyncControlStatus BrakeSyncControl_Evaluate(const BrakeSyncControlInputs *inputs,
                                                 BrakeSyncControlResult *result)
{
    if (result == NULL)
    {
        return BRAKESYNC_CONTROL_STATUS_INVALID_ARGUMENT;
    }

    /* 无论输入何种情况，先清除上一周期状态并禁止任何输出。 */
    (void)BrakeSyncControl_Init(result);
    if (inputs == NULL)
    {
        return BRAKESYNC_CONTROL_STATUS_INVALID_ARGUMENT;
    }

    result->input_quality_ready =
        inputs->brake_intent_valid && inputs->motion_input_valid;
    result->brake_intent_observed =
        inputs->brake_intent_valid && inputs->brake_intent_active;

    /*
     * 未来制动控制律、制动器参数、功率电路、安全许可均未审批。
     * 不提供任何可使能真实制动的行为。
     */
    return BRAKESYNC_CONTROL_STATUS_OK;
}
