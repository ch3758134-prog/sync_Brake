#include "brakesync/control_core.h"

#include <assert.h>
#include <stddef.h>
#include <stdio.h>

static void CheckOutputIsDisabled(const BrakeSyncControlResult *out)
{
    assert(!out->logical_request_valid);
    assert(out->logical_request_permille == 0U);
    assert(!out->physical_output_permitted);
}

static void TestInitialization(void)
{
    BrakeSyncControlResult out;
    assert(BrakeSyncControl_Init(&out) == BRAKESYNC_CONTROL_STATUS_OK);
    assert(!out.input_quality_ready);
    assert(!out.brake_intent_observed);
    CheckOutputIsDisabled(&out);
}

static void TestInvalidInputs(void)
{
    const BrakeSyncControlInputs in = {false, true, false};
    BrakeSyncControlResult out;
    assert(BrakeSyncControl_Evaluate(&in, &out) == BRAKESYNC_CONTROL_STATUS_OK);
    assert(!out.input_quality_ready);
    assert(!out.brake_intent_observed);
    CheckOutputIsDisabled(&out);
}

static void TestBrakeIntentIsOnlyObserved(void)
{
    const BrakeSyncControlInputs in = {true, true, true};
    BrakeSyncControlResult out;
    assert(BrakeSyncControl_Evaluate(&in, &out) == BRAKESYNC_CONTROL_STATUS_OK);
    assert(out.input_quality_ready);
    assert(out.brake_intent_observed);
    CheckOutputIsDisabled(&out);
}

static void TestReevaluationClearsPreviousStatus(void)
{
    const BrakeSyncControlInputs on = {true, true, true};
    const BrakeSyncControlInputs off = {false, false, true};
    BrakeSyncControlResult out;
    assert(BrakeSyncControl_Evaluate(&on, &out) == BRAKESYNC_CONTROL_STATUS_OK);
    assert(BrakeSyncControl_Evaluate(&off, &out) == BRAKESYNC_CONTROL_STATUS_OK);
    assert(!out.input_quality_ready);
    assert(!out.brake_intent_observed);
    CheckOutputIsDisabled(&out);
}

static void TestNullArguments(void)
{
    const BrakeSyncControlInputs in = {true, true, true};
    BrakeSyncControlResult out;
    assert(BrakeSyncControl_Init(NULL) == BRAKESYNC_CONTROL_STATUS_INVALID_ARGUMENT);
    assert(BrakeSyncControl_Evaluate(&in, NULL) == BRAKESYNC_CONTROL_STATUS_INVALID_ARGUMENT);
    assert(BrakeSyncControl_Evaluate(NULL, &out) == BRAKESYNC_CONTROL_STATUS_INVALID_ARGUMENT);
    assert(!out.input_quality_ready);
    assert(!out.brake_intent_observed);
    CheckOutputIsDisabled(&out);
}

int main(void)
{
    TestInitialization();
    TestInvalidInputs();
    TestBrakeIntentIsOnlyObserved();
    TestReevaluationClearsPreviousStatus();
    TestNullArguments();
    puts("Host tests PASS: all observed paths keep logical and physical output inhibited");
    return 0;
}
