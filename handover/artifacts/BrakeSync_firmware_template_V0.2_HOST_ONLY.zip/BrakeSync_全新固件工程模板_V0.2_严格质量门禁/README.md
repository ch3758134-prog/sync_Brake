# BrakeSync｜全新固件工程模板 V0.2（严格质量门禁起步版）

**状态：HOST-ONLY / QA-BASELINE-CREATED / NOT-MISRA-COMPLIANT / NOT-TARGET-VERIFIED。** 本模板全新建立，无历史固件/App 代码复用，也不包含厂商 SDK。新增严格编译器警告、项目汽车电子软件规范、MISRA 偏离和供应商记录模板、SW-01 目标工程核验清单。**不能将 QA 文件存在等同于规范合规或目标芯片验证通过。**

## 立即运行 Host 门禁

Linux/macOS、安装 GCC/Clang+CMake+Ninja 的终端：

```sh
./qa/run_host_gate.sh
```

或在支持 CMake Presets 的 Windows 终端依次执行：

```powershell
cmake --preset host-debug-strict
cmake --build --preset host-debug-strict
ctest --preset host-debug-strict
cmake --preset host-release-strict
cmake --build --preset host-release-strict
ctest --preset host-release-strict
```

## 质量与后续工程

- [强制规范](docs/AUTOMOTIVE_SW_STANDARD.md)
- [质量门禁及当前状态](docs/QUALITY_GATES.md)
- [SW-01 完整 YCT/Target 工程验收](docs/SW01_TARGET_PROJECT_CHECKLIST.md)
- [硬件驱动开发任务](docs/DRIVER_TASKS.md)
- [环境准备](docs/ENVIRONMENT.md)

当前 ASW 核心只处理输入有效性并且**始终禁止真实功率许可**。代码仍处于演示性起点：并无受控算法、实际制动输出、完整 MISRA 检查工具、目标 SDK 或安全分析证据。

**注意**：未获独立批准不得连接任何实际拖挂制动器或功率链路；后续 Target 工程由官方 YCT 生成、记录版本和校验，不能照搬旧仓库实现。
