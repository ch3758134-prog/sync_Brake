# 测试证据记录模板

- 任务编号：
- 目标/功能：
- 方案/板型 Rev / MCU 顶标：
- YCT/SDK/编译器版本：
- 软件 commit / branch：
- 供电、连线、模块型号、测试仪器：
- 测试类型：HOST / TARGET_BUILD / FLASH / TARGET_RUNTIME / MODULE_HW / INTEGRATION / POWER_BENCH / VEHICLE
- 构建/烧录命令及原始日志：
- 输入刺激（正常/异常）：
- 预期行为：
- 观察数据/波形：
- 结果：NOT_RUN / PASS / FAIL / BLOCKED
- 缺陷或风险：
- 回归结论：

禁止把 HOST PASS 当作 TARGET PASS。当前模板没有实体制动器功率输出能力。
