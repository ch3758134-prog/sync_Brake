# 开发环境从零准备

## 目标硬件

开发板：`YTM32B1LE0-EVB-LQFP64`，**实际 PCB Revision 与芯片顶标待核实**。历史资料中同时存在 RevA 参考手册、RevC 原理图和对应 MCU 新版本注释；必须先核实实板。

## 推荐 Windows 工具组合（方案，不代表已经安装成功）

1. VS Code + C/C++ + CMake Tools；Git；CMake；Ninja。
2. 云途官方 YCT (Yuntu Config Tool)，以及与实际 YTM32B1LE0 精确型号匹配的完整 SDK。
3. Arm GNU Toolchain / arm-none-eabi-gcc（与 YCT 生成工程兼容的版本；不要用电脑普通 gcc 构建 ARM 固件）。也可选 Keil/IAR，但建议先固定一套工具链，减少版本分歧。
4. 与实板支持情况匹配的 J-Link 或官方推荐的调试器及驱动，供电、USB-UART/串口终端、示波器/逻辑分析仪。
5. CAN USB 分析仪/第二节点与对应总线端接；根据实物模块为 UART/I²C/SPI 再准备连接和电平转换。

## 环境确认命令示例

```powershell
where.exe git
where.exe cmake
where.exe ninja
where.exe arm-none-eabi-gcc
arm-none-eabi-gcc --version
```

以上命令只能证明工具安装/路径。还需 YCT 新工程 Target 构建、正确下载目标、实际烧录、调试才能证明完整链路可用。

## 必须固定的软件身份

| 项目 | 记录 |
|---|---|
| MCU 精确 Part Number / silicon revision | 待实物核对 |
| EVB PCB Rev 与原理图 | 待实物核对 |
| YCT 版本 | 待核对 |
| SDK 包名称、版本、Hash、许可 | 待核对 |
| ARM 工具链名称/版本 | 待核对 |
| J-Link/Ozone/JFlash 或其它调试器版本 | 待核对 |
| 输出设备/传感器型号、供电、接线 | 待核对 |

历史 bring-up ZIP 仅能表明曾出现 SDK `1_5_0`、YCT 生成目录等记录，不能据此声明当前机器有完整 SDK，不能整包复制形成新工程。
