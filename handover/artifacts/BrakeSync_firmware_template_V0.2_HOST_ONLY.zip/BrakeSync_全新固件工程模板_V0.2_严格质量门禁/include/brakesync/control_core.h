#ifndef BRAKESYNC_CONTROL_CORE_H
#define BRAKESYNC_CONTROL_CORE_H

#include <stdbool.h>
#include <stdint.h>

/*
 * 制动业务核心接口，仅用于安全输出禁止阶段的逻辑输入测试。
 * 无实际制动算法/执行接口；所有 public API 返回明确的状态。
 */
typedef enum
{
    BRAKESYNC_CONTROL_STATUS_OK = 0,
    BRAKESYNC_CONTROL_STATUS_INVALID_ARGUMENT = 1
} BrakeSyncControlStatus;

typedef struct
{
    bool brake_intent_valid;
    bool brake_intent_active;
    bool motion_input_valid;
} BrakeSyncControlInputs;

typedef struct
{
    bool input_quality_ready;
    bool brake_intent_observed;

    /* 不存在获批的控制律和请求阈值，逻辑请求始终无效。 */
    bool logical_request_valid;
    uint16_t logical_request_permille;

    /* 当前版本无功率硬件使能/输出路径；必须始终禁止。 */
    bool physical_output_permitted;
} BrakeSyncControlResult;

/*
 * 初始化明确覆盖全部输出字段；不保留历史状态。
 * result 为 NULL 时返回 INVALID_ARGUMENT。
 * 非重入状态为无：模块不持有全局可写状态或 MCU 资源。
 */
BrakeSyncControlStatus BrakeSyncControl_Init(BrakeSyncControlResult *result);

/*
 * 每次调用均先将结果设为已知禁止状态，之后按有效输入设置观测字段。
 * 任一指针为空返回 INVALID_ARGUMENT，绝不许可制动输出。
 */
BrakeSyncControlStatus BrakeSyncControl_Evaluate(const BrakeSyncControlInputs *inputs,
                                                 BrakeSyncControlResult *result);

#endif /* BRAKESYNC_CONTROL_CORE_H */
