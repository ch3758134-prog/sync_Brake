#!/usr/bin/env sh
# Host 质量门禁：编译和单元测试。不能用于宣称 MISRA 或 Target 符合性。
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
printf '%s\n' '=== BrakeSync Host Strict Gate ==='
cmake --version | sed -n '1p'
"${CC:-cc}" --version | sed -n '1p'
cmake --preset host-debug-strict
cmake --build --preset host-debug-strict
ctest --preset host-debug-strict
cmake --preset host-release-strict
cmake --build --preset host-release-strict
ctest --preset host-release-strict
printf '%s\n' '=== Host strict builds and test suites: PASS ==='
printf '%s\n' 'NOT CHECKED: MISRA, Target build, Hardware, Safety compliance, Brake actuation'
