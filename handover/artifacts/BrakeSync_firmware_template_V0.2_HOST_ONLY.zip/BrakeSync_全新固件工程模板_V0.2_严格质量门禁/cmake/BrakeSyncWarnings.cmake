# 所有 C 源码都应用此处定义的 Host 编译器严格诊断规则。
# 这只是编译器诊断，不是 MISRA 规则验证。
add_library(brakesync_warnings INTERFACE)
if(CMAKE_C_COMPILER_ID STREQUAL "GNU")
    target_compile_options(brakesync_warnings INTERFACE
        -Wall -Wextra -Wpedantic -Werror
        -Wconversion -Wsign-conversion -Wshadow
        -Wformat=2 -Wundef -Wcast-qual -Wstrict-prototypes
        -Wmissing-prototypes -Wvla -Wpointer-arith
        -Wdouble-promotion
    )
elseif(CMAKE_C_COMPILER_ID MATCHES "Clang")
    target_compile_options(brakesync_warnings INTERFACE
        -Wall -Wextra -Wpedantic -Werror
        -Wconversion -Wsign-conversion -Wshadow
        -Wformat=2 -Wundef -Wcast-qual -Wstrict-prototypes
        -Wmissing-prototypes -Wvla -Wpointer-arith
        -Wdouble-promotion
    )
else()
    message(FATAL_ERROR "Host strict quality gate only supports tested GNU/Clang compiler families; configure target options separately")
endif()
