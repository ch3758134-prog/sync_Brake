#include "brakesync/control_core.h"

void BrakeSyncControl_Init(BrakeSyncControlResult *result)
{
    if (result == 0)
    {
        return;
    }

    result->input_quality_ready = false;
    result->brake_intent_observed = false;
    result->logical_request_valid = false;
    result->logical_request_permille = 0U;
    result->physical_output_permitted = false;
}

void BrakeSyncControl_Evaluate(const BrakeSyncControlInputs *inputs,
                               BrakeSyncControlResult *result)
{
    if (result == 0)
    {
        return;
    }

    /* 每个周期显式覆盖所有输出，防止复用上周期值。 */
    BrakeSyncControl_Init(result);
    if (inputs == 0)
    {
        return;
    }

    result->input_quality_ready =
        inputs->brake_intent_valid && inputs->motion_input_valid;
    result->brake_intent_observed =
        inputs->brake_intent_valid && inputs->brake_intent_active;

    /*
     * 尚缺正式控制律、产品参数、输出执行电路及安全分析。
     * 故逻辑请求和实体制动许可均保持禁用。
     */
}
