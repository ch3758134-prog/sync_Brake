# BrakeSync 全新固件工程模板 V0.1

**性质：独立新建的 C 工程骨架。** 不包含、不复制任何旧 GitHub 固件/App 代码，也不打包厂商 SDK。当前只支持 Host 构建，**不支持直接进行云途 MCU Target 构建**。

## 已实现

- C11 严格编译的共用控制框架（只接受输入语义、报告输入有效性）。
- 默认的**物理制动输出禁用**：没有任何真实功率驱动实现或 API，可生成的逻辑制动请求无效。
- Host smoke 入口和三类单元测试（初始化、无效输入、制动意图输入）；本模板没有真实控制律、波形或传感算法。
- 留出 `target/ytm32b1le0/` 的官方 YCT/SDK 接入位置，**不自行猜测 MCU 中断/寄存器或引脚映射**。

## Host 构建（本模板已验证）

```sh
cmake -S . -B build/host -G Ninja -DCMAKE_BUILD_TYPE=Debug
cmake --build build/host
ctest --test-dir build/host --output-on-failure
./build/host/brakesync_host_smoke   # Windows 通常为 .exe
```

这些命令只能证明在运行它们的机器上能构建 Host 测试，不等于 ARM Target 编译、烧录或真实制动功能通过。

## MCU Target 建立路线

1. 核对 `YTM32B1LE0-EVB-LQFP64` 实板 Revision、MCU 具体顶标和接口连接，确定使用的 YCT/SDK/编译器完整版本。
2. **用 YCT 新建独立的 YTM32B1LE0 SDK 工程**，先编译生成的空工程，完成下载、单步和串口/LED（由实板资料确认）实验。
3. 在 YCT 生成的工程中引用 `include/brakesync/control_core.h` 与 `src/asw/control_core.c`，而不是将生成工程代码复制到本目录或手工改 SDK 源文件。
4. 逐个做 GPIO、时间基准、UART DMA、CAN、外部传感模块等独立验证；详见 [任务与验收](docs/DRIVER_TASKS.md)。
5. 在专用电路/台架设计和安全审批前，**不得实现或连通真实房车制动功率输出**。

## 工程边界

- `src/asw`：不依赖 MCU SDK 的业务/控制纯逻辑。
- `target/ytm32b1le0`：YCT/SDK 生成工程及板级适配的管理指引；当前不含目标驱动。
- `tests/`：Host 单元测试；与板上测试分开。
- `docs/`：环境、驱动任务、安全限制和验证证据记录格式。

**注意**：本工程中的输入示例是模拟数据，只用于测试软件接口，不能据此宣称制动功能已经形成。
