#include "brakesync/control_core.h"
#include <stdio.h>

int main(void)
{
    const BrakeSyncControlInputs example = {true, true, true};
    BrakeSyncControlResult out;
    BrakeSyncControl_Init(&out);
    BrakeSyncControl_Evaluate(&example, &out);
    printf("example: input_quality=%u, brake_intent=%u, request_valid=%u, output_permitted=%u\n",
           out.input_quality_ready ? 1U : 0U,
           out.brake_intent_observed ? 1U : 0U,
           out.logical_request_valid ? 1U : 0U,
           out.physical_output_permitted ? 1U : 0U);
    return 0;
}
