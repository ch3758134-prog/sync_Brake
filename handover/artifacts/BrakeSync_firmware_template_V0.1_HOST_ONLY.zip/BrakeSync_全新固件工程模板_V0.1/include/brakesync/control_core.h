#ifndef BRAKESYNC_CONTROL_CORE_H
#define BRAKESYNC_CONTROL_CORE_H

#include <stdbool.h>
#include <stdint.h>

/*
 * 制动业务核心的最小纯逻辑边界。
 * 当前不实现制动力计算，不提供功率执行接口。
 */
typedef struct
{
    bool brake_intent_valid;
    bool brake_intent_active;
    bool motion_input_valid;
} BrakeSyncControlInputs;

typedef struct
{
    bool input_quality_ready;
    bool brake_intent_observed;

    /* 尚未设计制动控制律，逻辑请求只能保持无效。 */
    bool logical_request_valid;
    uint16_t logical_request_permille;

    /* 当前版本始终为 false，不能用于许可实际功率输出。 */
    bool physical_output_permitted;
} BrakeSyncControlResult;

/* 不持有 MCU 外设资源、无动态内存分配、无隐藏全局状态。 */
void BrakeSyncControl_Init(BrakeSyncControlResult *result);
void BrakeSyncControl_Evaluate(const BrakeSyncControlInputs *inputs,
                               BrakeSyncControlResult *result);

#endif /* BRAKESYNC_CONTROL_CORE_H */
