#include "brakesync/control_core.h"

#include <assert.h>
#include <stdio.h>

static void CheckOutputIsDisabled(const BrakeSyncControlResult *out)
{
    assert(!out->logical_request_valid);
    assert(out->logical_request_permille == 0U);
    assert(!out->physical_output_permitted);
}

static void TestInitialization(void)
{
    BrakeSyncControlResult out;
    BrakeSyncControl_Init(&out);
    assert(!out.input_quality_ready);
    assert(!out.brake_intent_observed);
    CheckOutputIsDisabled(&out);
}

static void TestInvalidInputs(void)
{
    const BrakeSyncControlInputs in = {false, true, false};
    BrakeSyncControlResult out;
    BrakeSyncControl_Evaluate(&in, &out);
    assert(!out.input_quality_ready);
    assert(!out.brake_intent_observed);
    CheckOutputIsDisabled(&out);
}

static void TestBrakeIntentIsOnlyObserved(void)
{
    const BrakeSyncControlInputs in = {true, true, true};
    BrakeSyncControlResult out;
    BrakeSyncControl_Evaluate(&in, &out);
    assert(out.input_quality_ready);
    assert(out.brake_intent_observed);
    CheckOutputIsDisabled(&out);
}

static void TestReevaluationClearsPreviousStatus(void)
{
    const BrakeSyncControlInputs on = {true, true, true};
    const BrakeSyncControlInputs off = {false, false, true};
    BrakeSyncControlResult out;
    BrakeSyncControl_Evaluate(&on, &out);
    BrakeSyncControl_Evaluate(&off, &out);
    assert(!out.input_quality_ready);
    assert(!out.brake_intent_observed);
    CheckOutputIsDisabled(&out);
}

int main(void)
{
    TestInitialization();
    TestInvalidInputs();
    TestBrakeIntentIsOnlyObserved();
    TestReevaluationClearsPreviousStatus();
    puts("Host tests PASS: logical and physical output inhibited");
    return 0;
}
